#include"DxLib.h"
#define _USE_MATH_DEFINES
#include<math.h>
#include"Player.h"
#include"Main.h"



////���@�̏����l
const int PLAYER_POS_X = main.getSCREEN_WIDTH() / 2;
const int PLAYER_POS_Y = main.getSCREEN_HEIGHT() - 100;
const int PLAYER_WIDTH = 63;
const int PLAYER_HEIGHT = 120;
const int PLAYER_SPEED = 5;

Player player;

//Main main;


void Player::PlayerControl()
{
	
	//Main main;

	 saigo = main.getg_PlayerLeft();

	/*int PlayerPojishonRihght= DrawRotaGraph(g_player.x, g_player.y, 1.0f, 0, g_PlayerRight, TRUE, FALSE);*/
	/*int PlayerPojishonLeft = DrawRotaGraph(g_player.x, g_player.y, 1.0f, 0, g_PlayerLeft, TRUE, FALSE);*/
	DrawRotaGraph(g_player.x, g_player.y, 1.0f, 0, saigo, TRUE, FALSE);


	//�v���C���[�̕\��
	//�㉺���E�ړ�
	if (g_player.flg == TRUE) {

		DrawRotaGraph(g_player.x, g_player.y, 1.0f, 0, saigo, TRUE, FALSE);

		if (main.getNowKey() & PAD_INPUT_RIGHT) {

			saigo = main.getg_PlayerRight();

			/*int PlayerPojishonLeft = DrawRotaGraph(g_player.x, g_player.y, 1.0f, 0, g_PlayerLeft, TRUE, FALSE);*/

			/*DrawRotaGraph(g_player.x, g_player.y, 1.0f, M_PI / 20, g_PlayerRight, TRUE, FALSE);*/

			DrawRotaGraph(g_player.x, g_player.y, 1.0f, M_PI / 20, saigo, TRUE, FALSE);
			g_player.x += g_player.speed;


			saigo = main.getg_PlayerRight();


		}




		if (main.getNowKey() & PAD_INPUT_LEFT) {

			saigo = main.getg_PlayerLeft();

			/*DrawRotaGraph(g_player.x, g_player.y, 1.0f, M_PI / -20, g_PlayerLeft, TRUE, FALSE);*/

			DrawRotaGraph(g_player.x, g_player.y, 1.0f, M_PI / -20, saigo, TRUE, FALSE);
			g_player.x -= g_player.speed;


			saigo = main.getg_PlayerLeft();

		}




	}

	//��ʂ��͂ݏo���Ȃ��悤�ɂ���
	if (g_player.x < 32)  g_player.x = 32;

	if (g_player.x > main.getSCREEN_WIDTH() - 50)  g_player.x = main.getSCREEN_WIDTH() - 50;




}

void Player::getPlayer() {

	g_player.flg = TRUE;
	g_player.x = PLAYER_POS_X;
	g_player.y = PLAYER_POS_Y;
	g_player.speed = PLAYER_SPEED;
}

